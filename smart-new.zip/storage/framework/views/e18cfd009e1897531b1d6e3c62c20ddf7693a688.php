<?php $__env->startSection('mahasiswa'); ?>

<div class="page-inner py-10">
    <div class="card">
        <div class="card-body">
            <?php
                $no = 1
            ?>
            <form action="/mahasiswa/cekevaluasi" method="POST">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                            <h3><?php echo e($no); ?>.</h3>
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <h3><?php echo e($s['soal']); ?> </h3>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <label class="form-radio-label">
                                <input class="form-radio-input" type="radio" name="<?php echo e($no); ?>" value="<?php echo e(($s['jawaban'] === 'a') ? 1 : 0); ?>">
                                <span class="form-radio-sign"><?php echo e($s['a']); ?></span>
                            </label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <label class="form-radio-label">
                                <input class="form-radio-input" type="radio" name="<?php echo e($no); ?>" value="<?php echo e(($s['jawaban'] === 'b') ? 1 : 0); ?>">
                                <span class="form-radio-sign"><?php echo e($s['b']); ?></span>
                            </label>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <label class="form-radio-label">
                                <input class="form-radio-input" type="radio" name="<?php echo e($no); ?>" value="<?php echo e(($s['jawaban'] === 'c') ? 1 : 0); ?>">
                                <span class="form-radio-sign"><?php echo e($s['c']); ?></span>
                            </label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <label class="form-radio-label">
                                <input class="form-radio-input" type="radio" name="<?php echo e($no); ?>" value="<?php echo e(($s['jawaban'] === 'd') ? 1 : 0); ?>">
                                <span class="form-radio-sign"><?php echo e($s['d']); ?></span>
                            </label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-1">
                        </div>
                        <div class="col-sm-6 col-md-11">
                            <label class="form-radio-label">
                                <input class="form-radio-input" type="radio" name="<?php echo e($no); ?>" value="<?php echo e(($s['jawaban'] === 'e') ? 1 : 0); ?>">
                                <span class="form-radio-sign"><?php echo e($s['e']); ?></span>
                            </label>
                        </div>
                    </div>


                    <?php
                        $no++
                    ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="number" name="materi_id" id="materi_id" value="<?php echo e($materi_id); ?>" hidden>

                </div>
                <div class="card-action">
                <div class="d-flex align-items-center">
                    <h4 class="card-title"></h4>
                    <button class="btn btn-primary btn-round ml-auto" type="submit" >
                        Selesai
                    </button>
                </div>
                </div>
    </div>
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/evaluasi.blade.php ENDPATH**/ ?>