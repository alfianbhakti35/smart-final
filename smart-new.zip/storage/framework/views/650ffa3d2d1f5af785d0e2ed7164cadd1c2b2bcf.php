<?php $__env->startSection('mahasiswa'); ?>

<div class="page-inner py-5">
    <div class="row">

        <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-sm-6 col-md-3">
            <div class="card card-primary">
                    <div class="card-body skew-shadow">
                        <h3><a href="/mahasiswa/materi/<?php echo e($m['id']); ?>" class="stretched-link"> Matakuliah <?php echo e($m['nama']); ?> </a></h3>
                        <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($d['id'] === $m['dosen_id']): ?>
                                <h5 class="op-8"><?php echo e($d['nama']); ?></h5>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/matakuliah.blade.php ENDPATH**/ ?>