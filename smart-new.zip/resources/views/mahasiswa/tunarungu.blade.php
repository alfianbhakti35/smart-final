@extends('layouts.mahasiswa')

@section('mahasiswa')

    <div class="page-inner py-5">
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto">

                <iframe width="560" height="315" src="https://www.youtube.com/embed/{{ $vidio['0'] }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                {{-- Jawab Soal Evaluasi --}}


            </div>

        </div>
    </div>

@endsection
