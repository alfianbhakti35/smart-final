@extends('layouts.admin')
@section('admin')

<div class="page-inner">
    <div class="page-header">
        @foreach ($mhs as $m )
            <h4 class="page-title">Edit Dosen</h4>

        @endforeach
    </div>



@endsection
