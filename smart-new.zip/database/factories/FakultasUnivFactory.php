<?php

namespace Database\Factories;

use App\Models\FakultasUniv;
use Illuminate\Database\Eloquent\Factories\Factory;

class FakultasUnivFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FakultasUniv::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
