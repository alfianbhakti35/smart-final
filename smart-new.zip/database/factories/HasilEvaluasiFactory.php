<?php

namespace Database\Factories;

use App\Models\HasilEvaluasi;
use Illuminate\Database\Eloquent\Factories\Factory;

class HasilEvaluasiFactory extends Factory
{
    protected $model = HasilEvaluasi::class;

    public function definition()
    {
        return [
            //
        ];
    }
}
