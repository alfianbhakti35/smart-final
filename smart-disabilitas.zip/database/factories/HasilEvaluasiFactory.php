<?php

namespace Database\Factories;

use App\Models\HasilEvaluasi;
use Illuminate\Database\Eloquent\Factories\Factory;

class HasilEvaluasiFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = HasilEvaluasi::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
