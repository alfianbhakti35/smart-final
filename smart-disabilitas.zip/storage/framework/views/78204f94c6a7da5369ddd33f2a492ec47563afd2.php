<?php $__env->startSection('mahasiswa'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/keritik.blade.php ENDPATH**/ ?>