<?php $__env->startSection('mahasiswa'); ?>

<div class="page-inner py-10">
    <div class="text-center">
        <audio src="<?php echo e(asset('storage/' . $mp3)); ?>" controls></audio>
    </div>
</div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/tunanetra.blade.php ENDPATH**/ ?>