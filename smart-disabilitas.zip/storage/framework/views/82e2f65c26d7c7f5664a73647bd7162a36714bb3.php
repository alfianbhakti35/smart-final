<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">

            <ul class="nav nav-success">
                <li class="nav-item <?php echo e(($title === "Dashboard") ? 'active' : ''); ?>">
                    <a href="/dosen" class="" aria-expanded="false">
                        <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item <?php echo e(($title === "Materi") ? 'active' : ''); ?>">
                    <a href="/dosen/materi" class="" aria-expanded="false">
                        <i class="fas fa-book"></i>
                        <p>Materi</p>
                    </a>
                </li>

                <li class="nav-item <?php echo e(($title === "Hasil Evaluasi") ? 'active' : ''); ?>">
                    <a href="/dosen/evaluasi" class="" aria-expanded="false">
                        <i class="fas fa-bookmark"></i>
                        <p>Hasil Evaluasi</p>
                    </a>
                </li>

                
                

            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/menu/dosen.blade.php ENDPATH**/ ?>