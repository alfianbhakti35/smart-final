<?php $__env->startSection('mahasiswa'); ?>

<div class="page-inner py-5">
    <div class="row">

        <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
            <div class="card">
                <img class="card-img-top" src="https://random.imagecdn.app/500/150">
                <div class="card-body">
                    <b>
                        <h5 class="card-title"><?php echo e($m['nama']); ?></h5>
                    </b>
                    <p class="card-text"></p>
                    <a href="/mahasiswa/tunanetra/<?php echo e($m['id']); ?>" class="btn btn-primary">Tunanetra</a>
                    <a href="/mahasiswa/tunarungu/<?php echo e($m['id']); ?>" class="btn btn-primary">Tunarungu</a>
                    <a href="/mahasiswa/slow/<?php echo e($m['id']); ?>" class="btn btn-primary">Slow Learning</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/materi.blade.php ENDPATH**/ ?>