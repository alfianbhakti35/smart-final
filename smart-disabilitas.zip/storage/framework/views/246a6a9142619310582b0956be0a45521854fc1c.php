<?php $__env->startSection('mahasiswa'); ?>

    <div class="page-inner py-5">
        <div class="row">
            <div class="ml-auto mr-auto">
                <iframe src="<?php echo e(asset('storage/' . $pdf)); ?>" width="900" height="500"></iframe>

                


            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/slow.blade.php ENDPATH**/ ?>