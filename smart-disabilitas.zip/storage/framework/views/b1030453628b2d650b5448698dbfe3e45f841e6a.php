<?php $__env->startSection('dosen'); ?>

<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">Hasil Evaluasi Mahasiswa</h4>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h4 class="card-title"></h4>
                        <button class="btn btn-primary btn-round ml-auto" data-toggle="modal" data-target="#addRowModal">
                            <i class="fa fa-plus"></i>
                            Export Data
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="add-row" class="display table table-striped table-hover" >
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 40%">Nama Mahasiswa</th>
                                    <th>Materi</th>
                                    <th>Matakuliah</th>
                                    <th>Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                

                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>

                                

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/dosen/evaluasi.blade.php ENDPATH**/ ?>