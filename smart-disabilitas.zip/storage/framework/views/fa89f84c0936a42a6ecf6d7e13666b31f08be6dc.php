<?php $__env->startSection('mahasiswa'); ?>

<div class="page-inner py-10">
    <div class="text-center">
        <h1>Nilai Anda Adalah:</h1>
        <div id="circles-1"></div>
		<h6 class="fw-bold mt-3 mb-0">
            <?php if($nilai <= 50): ?>
                Cukup
            <?php elseif($nilai <= 80): ?>
                Baik
            <?php elseif($nilai <= 99): ?>
                Sangat Baik

            <?php elseif($nilai == 100): ?>
                Sempurna
            <?php endif; ?>
        </h6>


        <a href="/mahasiswa" class="btn btn-primary btn-round mt-5">Dashboard</a>
    </div>
</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfian/Documents/php/smart-disabilitas/resources/views/mahasiswa/hasilevaluasi.blade.php ENDPATH**/ ?>